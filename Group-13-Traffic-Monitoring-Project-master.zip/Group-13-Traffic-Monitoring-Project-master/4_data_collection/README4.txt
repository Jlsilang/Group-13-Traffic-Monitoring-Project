Jason Yang, Charu Jain, Justin Silang, Maxine Deines, Mehul Salhotra, Akshay Sardana

The CollectScript is the main python file to be run to retrieve traffic data and weather.

To run on webhost:

	i.e. Run a cron job on the webhost control panel. After selecting the frequency of cron job to run, we will use linux commands, we need to input the path of the CollectScript.py in our Command input box.
In our case the path is: /home/jlsilang/public_html/cgi-bin/CollectScript.py
	

