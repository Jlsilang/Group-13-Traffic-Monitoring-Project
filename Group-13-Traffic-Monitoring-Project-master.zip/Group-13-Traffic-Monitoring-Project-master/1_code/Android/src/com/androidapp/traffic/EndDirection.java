package com.androidapp.traffic;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EndDirection extends Activity implements OnInitListener{
	protected static final int REQUEST_OK = 1;
	protected static final int REQUEST_CONFIRM=2;
    private TextToSpeech tts;

	EditText street,city,state,zipcode;
	String address;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.end_direction);
		tts = new TextToSpeech(this, this);

	    street   = (EditText)findViewById(R.id.streetAddress);
	    city   = (EditText)findViewById(R.id.addressCity);
	    state   = (EditText)findViewById(R.id.addressState);
	    zipcode   = (EditText)findViewById(R.id.zipcodeAddress);

	    
	    

	}

	public void Submit(View v){
		Intent intent = new Intent(this,NewDirection.class);
		String address=street.getText().toString()+" "+city.getText().toString()+" "
				+state.getText().toString()+" "+zipcode.getText().toString();
		intent.putExtra("address", address);
		startActivity(intent);
	}
	
	public void Voice(View v){
		Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
       	 try {
            startActivityForResult(i, REQUEST_OK);
        } catch (Exception e) {
       	 	Toast.makeText(this, "Error initializing speech to text engine.", Toast.LENGTH_LONG).show();
        }
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	        super.onActivityResult(requestCode, resultCode, data);
	        if (requestCode==REQUEST_OK  && resultCode==RESULT_OK) {
	        	address="";
	        		ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
	        		//for (int i=0;i<thingsYouSaid.size();i++){
	        			address=address+thingsYouSaid.get(0);
	        		//}
	           	 //	Toast.makeText(this, address, Toast.LENGTH_LONG).show();

	                    if (!tts.isSpeaking()) {
	                    	tts.speak("Say yes if this is your address: "+address, TextToSpeech.QUEUE_FLUSH, null);
	                    }
	                    while(tts.isSpeaking());
	                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
	                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
	                   	 try {
	                        startActivityForResult(i, REQUEST_CONFIRM);
	                    } catch (Exception e) {
	                   	 	Toast.makeText(this, "Error initializing speech to text engine.", Toast.LENGTH_LONG).show();
	                    }   
		            
	        }else if(requestCode==REQUEST_CONFIRM  && resultCode==RESULT_OK){
        		ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        		if(thingsYouSaid.get(0).toLowerCase().equals("yes")){
        			Intent intent = new Intent(this,NewDirection.class);
        			intent.putExtra("address", address);
        			startActivity(intent);
        		}else{
        			
        			if (!tts.isSpeaking()) {
                    	tts.speak("This is not your address. Press the button to try again.", TextToSpeech.QUEUE_FLUSH, null);
                    }
        			
        		}
	        }
	    }

	@Override
	public void onInit(int code) {
		if (code==TextToSpeech.SUCCESS) {
	    tts.setLanguage(Locale.getDefault());
	} else {
		tts = null;
			Toast.makeText(this, "Failed to initialize TTS engine.",
			Toast.LENGTH_SHORT).show();
	}
	}
	
	@Override
	protected void onDestroy() {
	      if (tts!=null) {
	tts.stop();


	tts.shutdown();


	}


	      super.onDestroy();
	}
}
