#!/usr/bin/python
print "Content-Type: text/html\n"
print "hello world"